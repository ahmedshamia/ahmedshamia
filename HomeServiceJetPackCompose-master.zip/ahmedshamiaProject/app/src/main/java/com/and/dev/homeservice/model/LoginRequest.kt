package com.and.dev.homeservice.model

data class LoginRequest(
    val email: String,
    val password: String
)